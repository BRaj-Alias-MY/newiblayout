import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../../services/api.service';

@Injectable({
  providedIn: 'root'
})
export class ExpertService {
  constructor(private main_api: ApiService, private http: HttpClient) {}
  get_interviewids() {
    return this.http.get<any>(
      this.main_api.get_base() + 'expert-review/assign-interviews-list/'
    );
  }
  get_experts() {
    return this.http.get<any>(this.main_api.get_base() + 'user/experts/list');
  }

  save_interviewassign(data) {
    return this.http.post<any>(
      this.main_api.get_base() + 'expert-review/assign-interview',
      data
    );
  }
  get_expertlist() {
    return this.http.get<any>(
      this.main_api.get_base() + 'expert-review/interview-list-expert'
    );
  }
  get_interviewQuestions(id) {
    // http://localhost:3000/api/expert-review/interview-list-expert/2
    return this.http.get<any[]>(
      this.main_api.get_base() + 'expert-review/interview-list-expert/' + id
    );
  }
  getInterviewById(id) {
    return this.http.get<any>(
      this.main_api.get_base() + 'expert-review/getInterviewById/' + id );
  }
  saveReview(data, id) {
    return this.http.post<any>( this.main_api.get_base() + 'expert-review/save-review-question/' + id , data);
  }
  postReview(data, id) {
    return this.http.post<any>( this.main_api.get_base() + 'expert-review/review-submit/' + id , data);
  }
}
