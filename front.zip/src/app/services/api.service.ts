import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
	providedIn: 'root'
})
export class ApiService {
	auth_token: any;
	user: any;
	constructor(private http: HttpClient) {}

	base = 'http://localhost:3000/api/';

	get_base(): string {
		return this.base;
	}
	logout(): any {
		this.auth_token = null;
		this.user = null;
		localStorage.clear();
	}

	storageuserdata(token, user): void {
		localStorage.setItem('token', token);
		localStorage.setItem('user', JSON.stringify(user));
		this.auth_token = token;
		this.user = user;
	}

	loadToken() {
		this.auth_token = localStorage.getItem('token');
	}

	getToken(): string {
		return localStorage.getItem('token');
	}

	getUser(): any {
		return JSON.parse(localStorage.getItem('user'));
	}
	add_register(data): any {
		//user.password = this.encryptdata(user.password);
		return this.http.post<any>(this.base + 'public/signup', data);
	}
	login(user): any {
		return this.http.post<any>(this.base + 'public/login', user);
	}
	forgetpwd(data): any {
		return this.http.post<any>(this.base + 'public/forget-password', data);
	}
	createuser(user): any {
		return this.http.post<any>(this.get_base() + 'public/signup', user);
	}

	menu(): any {
		return this.http.get<any>(this.get_base() + 'user/menu');
	}

	admindashboard(): any {
		return this.http.get<any>(this.get_base() + 'dashboard/admin');
	}
	expertdashboard(): any {
		return this.http.get<any>(this.get_base() + 'dashboard/expert');
	}
	organizationdashboard(): any {
		return this.http.get<any>(this.get_base() + 'dashboard/orgination');
	}
	add_reset(data): any {
		return this.http.post<any>(this.base + 'user/change-password', data);
	}
}
