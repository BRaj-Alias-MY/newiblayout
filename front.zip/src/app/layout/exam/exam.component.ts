import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../app.service';
import {ApiService} from '../../services/api.service';
import { FormControl, FormGroup } from '@angular/forms';
@Component({
  selector: 'app-exam',
  templateUrl: './exam.component.html',
  styleUrls: ['./exam.component.css']
})
export class ExamComponent implements OnInit {

  constructor(private router: Router, private service: AppService, private api:ApiService) { }
  interviews = [];


  ngOnInit() {
    this.getInterview();
  }
  logout() {
    this.api.logout();
    this.router.navigate(['/login']);
  }

  getInterview() {
    let email = localStorage.getItem('email');
    //alert(this.email + this.domain + this.subdomain);
    this.service.getInterviews()
      .subscribe(resp => { this.interviews = resp; console.log(this.interviews) }, err => console.log(err));
  }
}
