/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  const domain = sequelize.define('domain', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    domainName: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('active','inactive'),
      allowNull: false
    }
  }, {
    tableName: 'domain'
  });
  domain.associate = function(models) {
    domain.hasMany(models.sub_domains, {foreignKey: 'domainId', targetKey: 'id'});
    domain.hasMany(models.questions, {foreignKey: 'domainId', targetKey: 'id'});
  };
  return domain;
};
