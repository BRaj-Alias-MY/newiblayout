module.exports = function(sequelize, DataTypes) {
  const menu_access_map = sequelize.define('menu_access_map', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    menuId: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    roleId: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    addAccess: {
      type: DataTypes.ENUM('0','1'),
      allowNull: false
    },
    editAccess: {
      type: DataTypes.ENUM('0','1'),
      allowNull: false
    },
    gridAccess: {
      type: DataTypes.ENUM('0','1'),
      allowNull: false
    },
    viewAccess: {
      type: DataTypes.ENUM('0','1'),
      allowNull: false
    },
    deleteAccess: {
      type: DataTypes.ENUM('0','1'),
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'menu_access_map'
  });
  menu_access_map.associate = function(models) {
      menu_access_map.belongsTo(models.roles, {foreignKey: 'roleId', targetKey: 'id'});
      menu_access_map.belongsTo(models.menu_master, {foreignKey: 'menuId', targetKey: 'id'});
  };
  return menu_access_map;
};
