/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  const users = sequelize.define('users', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    fname: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    mname: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    lname: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    email: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    password: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    phone: {
      type: DataTypes.STRING(12),
      allowNull: true
    },
    gender: {
      type: DataTypes.ENUM('male','female','others'),
      allowNull: false
    },
    organizationId: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      references: {
        model: 'organization_campus',
        key: 'id'
      }
    },
    status: {
      type: DataTypes.ENUM('active','inactive','suspend',''),
      allowNull: true
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    roleId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'roles',
        key: 'id'
      }
    }
  }, {
    tableName: 'users'
  });
  
  users.associate = function(models) {
    users.belongsTo(models.roles,{foreignKey: 'roleId'});
    users.belongsTo(models.organization_campus,{foreignKey: 'organizationId'});
    users.hasMany(models.user_groups_map,{foreignKey: 'userId'});
    users.hasMany(models.user_profile_subdomains,{foreignKey: 'userId'});
    users.hasMany(models.user_profile,{foreignKey: 'userId'});
  };
  return users;
};
