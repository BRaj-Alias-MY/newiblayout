module.exports = function(sequelize, DataTypes) {
  const menu_modules_master = sequelize.define('menu_modules_master', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    menuTitle: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    menuLink: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    priority: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('0','1'),
      allowNull: false
    },
    icon: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'menu_modules_master'
  });
  menu_modules_master.associate = function(models) {
      menu_modules_master.hasMany(models.menu_master, {foreignKey: 'moduleId', targetKey: 'id'});
  };
  return menu_modules_master;
};
