'use strict';
module.exports = (sequelize, DataTypes) => {
  const AsyncInterview = sequelize.define (
    'AsyncInterview',
    {
      InterviewId: DataTypes.INTEGER,
      email: DataTypes.STRING,
      link: DataTypes.TEXT,
      pin: DataTypes.INTEGER,
      status: {
        type: DataTypes.ENUM,
        values: ['Available', 'Verified', 'Submitted', 'Completed', 'Reviewed'],
      },
      paymentstatus: {
        type: DataTypes.ENUM,
        values: ['Pending', 'Success'],
      },
      packageType: DataTypes.STRING,
      price: DataTypes.FLOAT,
      unvId: DataTypes.INTEGER,
      createdBy: DataTypes.INTEGER,
      discount: DataTypes.FLOAT,
      domain: DataTypes.INTEGER,
      subdomain: DataTypes.INTEGER,
    },
    {}
  );
  AsyncInterview.associate = function (models) {
    // associations can be defined here
  };
  return AsyncInterview;
};
