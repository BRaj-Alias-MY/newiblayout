var app = require('express');
var router = app.Router();
var user = require('../models').users;
var roles = require('../models').roles;
var organization = require('../models').organization;
var organization_campus = require('../models').organization_campus;
var menu_modules_master = require('../models').menu_modules_master;
var menu_access_map = require('../models').menu_access_map;
var menu_master = require('../models').menu_master;
var sub_domains = require('../models').sub_domains;
var config = require('../config/keys');
var crypto = require('crypto');
let sequelize = require('../models').sequelize;
const Op = sequelize.Op;
let mails = require('./email');
const async = require('async');
const user_profile_subdomains = require('../models').user_profile_subdomains;
const user_groups_map = require('../models').user_groups_map;

router.get('/profile',(req,res)=>{
    user.findOne({ where: {id : req.auth.userId} }).then(users => {
        if(users){
            res.send({'status' : true, data : users});
        }else{
            res.send({'status' : false, 'message':'fail'});
        }
    })
});

router.post('/change-password',(req,res)=>{
    let hash = crypto.createHash('md5').update(req.body.newpassword).digest('hex');
    user.afterBulkUpdate(function(options) {//hook1
        options.auth = req.auth ? req.auth.userId : 0;
    });
    user.update({
        password:hash
    },{
        where: {id : req.auth.userId}
    }).then(result=>{
        res.send({'status' : true, data : result});
    });
});

router.get('/roles',(req,res)=>{
    roles.findAll({attributes: ['id', 'role_name'],where:{level:{[Op.gt]:req.auth.roleLevel}}}).then(roles => {
        res.send({'status':true,'data':roles});
    });
});

router.get('/get-users',(req,res)=>{
    user.findAll({ include: [{model:roles},{model:organization_campus} ] }).then(users => {
        res.send({'status':true,'data':users});
    });
});

router.post('/create-user',(req,res)=>{
    var user_data = req.body;
    let sendMailPass = [];
    user.findOne({where:{email:user_data.email}}).then(userData=>{
        if(userData){
            res.send({status:false,message:'user already exist.'});
        }else{
            sequelize.transaction(function (t) {
                let password = require('crypto').randomBytes(7).toString('hex');
                let hash = crypto.createHash('md5').update(password).digest('hex');
                user.afterCreate(function(model, options, done) {//hook1
                    model.auth = req.auth ? req.auth.userId : 0;
                });
                if(user_data.organization){
                    return user.create({
                        fname:user_data.fname,
                        mname:user_data.mname,
                        lname:user_data.lname,
                        email:user_data.email,
                        password:hash,
                        phone:user_data.phone,
                        gender:user_data.gender,
                        status:'active',
                        roleId:user_data.rolesID,
                        organizationId:user_data.organization
                    },{transaction: t}).then(async (users)=>{
                        sendMailPass.push({'email':users.email,'content':"Password is: <b style='color:red'>"+password+"</b>"});
                        if((user_data.subdomain && user_data.subdomain.length>0) || (user_data.usergroup && user_data.usergroup.length>0)){
                            if(user_data.subdomain.length>0){
                                user_profile_subdomains.afterBulkCreate(function(model,options) {
                                    options.auth = req.auth ? req.auth.userId : 0;
                                });
                                await user_profile_subdomains.bulkCreate(user_data.subdomain.map(function(v,i) {
                                    return {userSkills:v.id, userId:users.id};
                                }),{transaction: t}).then(res=>{
                                    return true;
                                });
                            }
                            if(user_data.usergroup.length>0){
                                user_groups_map.afterBulkCreate(function(model,options) {
                                    options.auth = req.auth ? req.auth.userId : 0;
                                });
                                await user_groups_map.bulkCreate(user_data.usergroup.map(function(v,i) {
                                    return {groupId:v.id, userId:users.id};
                                }),{transaction: t}).then(res=>{
                                    return true;
                                });
                            }
                            return true;
                        }else{
                            return true;
                        }
                    });
                }else{
                    user.afterCreate(function(model, options, done) {//hook1
						model.auth = req.auth ? req.auth.userId : 0;
					});
                    return user.create({
                        fname:user_data.fname,
                        mname:user_data.mname,
                        lname:user_data.lname,
                        email:user_data.email,
                        password:hash,
                        phone:user_data.phone,
                        gender:user_data.gender,
                        status:'active',
                        roleId:user_data.rolesID
                    },{transaction: t}).then(async (users)=>{
                        sendMailPass.push({'email':users.email,'content':"Password is: <b style='color:red'>"+password+"</b>"});
                        if((user_data.subdomain && user_data.subdomain.length>0) || (user_data.usergroup && user_data.usergroup.length>0)){
                            if(user_data.subdomain.length>0){
                                user_profile_subdomains.afterBulkCreate(function(model,options) {
                                    options.auth = req.auth ? req.auth.userId : 0;
                                });
                                await user_profile_subdomains.bulkCreate(user_data.subdomain.map(function(v,i) {
                                    return {userSkills:v.id, userId:users.id};
                                }),{transaction: t}).then(res=>{
                                    return true;
                                });
                            }
                            if(user_data.usergroup.length>0){
                                user_groups_map.afterBulkCreate(function(model,options) {
                                    options.auth = req.auth ? req.auth.userId : 0;
                                });
                                await user_groups_map.bulkCreate(user_data.usergroup.map(function(v,i) {
                                    return {groupId:v.id, userId:users.id};
                                }),{transaction: t}).then(res=>{
                                    return true;
                                });
                            }
                            return true;
                        }else{
                            return true;
                        }
                    });
                }
            }).then(result=>{
                async.parallel([
                    function (callback) {
                        mails.sendEmail(
                        callback,
                        'iamchandu.20@gmail.com',
                        sendMailPass,
                        'IB Password'
                    );
                    }
                ], function(err, results) {
                    res.send({'status':true,'message':'User Created'});
                });
            }).catch(err=>{
                console.log(err);
                res.send({'status':false,'message':'Transcation Fail.'});
            })
        }
    })
});


router.post('/bulk-user-validate',async (req,res)=>{
    var user_data = req.body;
    let st = true;
    // =========== Check these emails already exist or not =================
    for(let o=0;o<user_data.length;o++){
        if(req.auth.organization){
            user_data[o].organizationId = req.auth.organization;
        }
        await user.findAndCountAll({ where: {email : user_data[o].email} }).then(async userCount=>{
            if(userCount.count>0){
                st = false;
                user_data[o].validation = 'Email already exist.';
            }else{
                user_data[o].status = 'active';
                user_data[o].roleId = 5;

                let subDmntest = user_data[o].subDomainName;
                subDmntest = subDmntest[0]=='"' ?  subDmntest.slice(1) : subDmntest;
                subDmntest = subDmntest[subDmntest.length - 1]=='"' ?  subDmntest.slice(0,-1) : subDmntest;
                let subdmns = subDmntest.split(',').filter(function (el) {
                    return el != '';
                  });

                await sub_domains.findAndCountAll({attributes: [['id','userSkills']], where: {subDomainName : {[Op.in]:subdmns},status:'active'} }).then(subdmnsData=>{
                    if(subdmns.length==subdmnsData.count){
                        user_data[o].subdmnsData = subdmnsData.rows;
                    }else{
                        console.log(subdmns.length);
                        console.log(subdmnsData.count);
                        st = false;
                        user_data[o].validation = 'Please verify subdomains.';
                    }
                });
            }
        });
    };
    await res.send({'status' : st, 'message':user_data});
});

router.post('/bulk-user',async (req,res)=>{
    //console.log(req.body);
    if(req.body.status){
        let sendMailPass = [];
        sequelize.transaction(function (t) {
            var promises = []
            let userdata = req.body.message;
            userdata.forEach(singleUser => {
                let password = require('crypto').randomBytes(7).toString('hex');
                let hash = crypto.createHash('md5').update(password).digest('hex');
                singleUser.password = hash;
                user.afterCreate(function(model, options, done) {//hook1
                    model.auth = req.auth ? req.auth.userId : 0;
                });
                let newPromise = user.create(singleUser, {transaction: t}).then(usersDataCreated=>{
                    user_profile_subdomains.bulkCreate(singleUser.subdmnsData.map(function(v,i) {
                        return {userSkills:v.userSkills, userId:usersDataCreated.id};
                    }),{transaction: t});
                    sendMailPass.push({'email':singleUser.email,'content':"Password is: <b style='color:red'>"+password+"</b>"});
                });
                promises.push(newPromise);
            });
            return Promise.all(promises);        
        }).then(function(result)  {
            console.log(sendMailPass);
            
            async.parallel([
                function (callback) {
                    mails.sendEmail(
                    callback,
                    'iamchandu.20@gmail.com',
                    sendMailPass,
                    'IB Password'
                );
                }
            ], function(err, results) {
                // res.send({
                //   success: true,
                //   message: 'Emails sent',
                //   successfulEmails: results[0].successfulEmails,
                //   errorEmails: results[0].errorEmails,
                // });
                res.send({'status' : true, "message" : 'success'});
            });
           
        }).catch(function (err) {
            console.log(err);
            res.send({'status' : false, "message" : 'Fail'});
        });
    }else{
        res.send({'status' : false, 'message':"Validation Failed."});
    }
});

router.get('/menu',(req,res)=>{
    console.log(req.auth.access);
    let qry = "SELECT GROUP_CONCAT(menuId) as menuId FROM `menu_access_map` where roleId="+req.auth.role+" and (addAccess=1 or editAccess=1 or gridAccess=1 or viewAccess=1 or deleteAccess=1) group by roleId";
    sequelize.query(qry, { type: sequelize.QueryTypes.SELECT}).then(dataAccess=>{
        menu_modules_master.findAll({ include: [{model:menu_master,where:{menuStatus
            :'1',id: {[Op.in]: dataAccess[0].menuId.split(",")}},required: false} ], order: [ ['priority', 'ASC'], ['id', 'ASC'], ] }).then(data=>{
            res.send({'status' : true, "data" : data});
        }).catch(err=>{
            console.log(err);
            res.send({'status' : false, "message" : 'Fail'});
        });
    }).catch(err=>{
        console.log(err);
        res.send({'status' : false, "message" : 'Fail'});
    });
});

router.get('/experts/list',(req,res)=>{
    user.findAll({attributes:['id',[sequelize.fn('CONCAT', sequelize.col('fname')," ",sequelize.col('lname')), 'name']],where:{roleId:3}}).then(data=>{
        if(data)
            res.send({status:true,data:data});
        else
            res.send({status:false,message:"no data found."})
    }).catch(err=>{
        console.log(err);
        res.send({status:false,message:"fail"});
    })
})
 router.get('/getusers',(req,res)=>{
     if(req.auth.access.gridAccess){
        let wharecond = {};
        if(req.auth.organization){
            wharecond = {where:{status:'active',organizationId:req.auth.organization,roleId:5}};
        }else{
            wharecond = {where:{status:'active',organizationId:req.auth.organization,roleId:{[Op.notIn]:[1,2]}}};
        }
        user.findAll({where:wharecond.where,include:[{model:roles}]}).then(data=>{
            
            res.send({status:true,"data" : data, access:req.auth.access});
        })
     }else{
         res.send({status:false,message:"unauthorized."})
     }
 })
module.exports = router;