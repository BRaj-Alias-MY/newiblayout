let app = require('express');
let router = app.Router();
let domain = require('../models').domain;
let sub_domains = require('../models').sub_domains;
let sequelize = require('../models').sequelize;
const Op = sequelize.Op;

router.get('/list',(req,res)=>{
	domain.findAll({attributes: ['id', 'DomainName'],where:{status:'active'}}).then(domain => {
		res.send({'status':true,'data':domain});
	}).catch(err=>{
		console.log(err);
		res.send({'status':fail,'message':"fail.."});
	});
});

router.get('/list/:id',(req,res)=>{
	sub_domains.findAll({attributes:['id','subDomainName'],where:{status:'active',domainId:req.params.id}}).then(subdomain => {
		res.send({'status':true,'data':subdomain});
	});
});

router.get('/',(req,res)=>{
      if(req.auth.access.gridAccess){
		domain.findAll({ include: [{model:sub_domains,where:{status:'active'},duplicating: false} ] }).then(domain => {
			if(domain){
				res.send({'status' : true, "data" : domain, access:req.auth.access});
			}else{
				res.send({'status' : false, 'message':'fail'});
			}
		}).catch(function (error) {
			res.status(500).send('Internal Server Error');
		});

	}else{
		res.send({'status' : false, 'message':'Un Autherized.', access:[req.auth.access]});
	}
});

router.post('/',(req,res)=>{
	if(req.auth.access.addAccess){
		return domain.findOne({ where: {domainName : req.body.domainName} }).then(domainDataSel => {
			if(domainDataSel){
				res.send({'status' : false, "message" : 'Domain already exists.'});
			}else{
				let user_data = req.body;
				
				return sequelize.transaction(function (t) {
					domain.afterCreate(function(model, options, done) {//hook1
						model.auth = req.auth ? req.auth.userId : 0;
					});
					return domain.create({
						domainName:user_data.domainName,
						status:'active'
					}, {transaction: t}).then((domainSave)=>{
						
						var promises = []
						user_data.domain.forEach(element => {
							sub_domains.afterCreate(function(model, options, done) {//hook1
								model.auth = req.auth ? req.auth.userId : 0;
							});
							let newPromise = sub_domains.create({
								subDomainName:element.subDomainName,
								domainId:domainSave.id,
								status:'active'
							}, {transaction: t});
							promises.push(newPromise);
						});
						return Promise.all(promises); 
					});
				}).then(function (result) {
				  	res.send({'status' : true, "message" : 'success'});
				}).catch(function (err) {
					console.log(err);
				  	res.send({'status' : false, "message" : 'Fail'});
				});
			}
		})
		
	}else{
		res.send({'status' : false, 'message':'Un Autherized.'});
	}
});

router.get('/:id',(req,res)=>{
	if(req.auth.access.viewAccess){
		domain.findOne({ where: {id : req.params.id},include: [{model:sub_domains,where:{status:'active'}} ] }).then(domain => {
        if(domain){
            res.send({'status' : true, "data" : domain});
        }else{
            res.send({'status' : false, 'message':'fail'});
        }
		})
	}else{
		res.send({'status' : false, 'message':'Un Autherized.'});
	}
});

router.post('/:id',(req,res)=>{
	//console.log(req.body);
	let domain_id = req.params.id;
	if(req.auth.access.editAccess && domain_id>0){
		let user_data = req.body;
		return sequelize.transaction(function (t) {
			domain.afterBulkUpdate(function(options) {//hook1
				options.auth = req.auth ? req.auth.userId : 0;
			});
			return domain.update({
				domainName:user_data.domainName
			},{ where: { id: domain_id }}, {transaction: t}).then((domainDataSave)=>{
				sub_domains.afterBulkUpdate(function( options) {//hook1
					options.auth = req.auth ? req.auth.userId : 0;
				});
				return sub_domains.update({
					status:'inactive'
				},{ where: { domainId: domain_id}}, {transaction: t}).then( result_of_up=>{
					var promises = []
					user_data.domain.forEach(element => {
						if(element.id>0){
							sub_domains.afterBulkUpdate(function(options) {//hook1
								options.auth = req.auth ? req.auth.userId : 0;
							});
							let newPromise = sub_domains.update({
								subDomainName:element.subDomainName,
								domainId:domain_id,
								status:'active'
							},{where: { id: element.id }}, {transaction: t});
							promises.push(newPromise);
						}else{
							sub_domains.afterCreate(function(model, options, done) {//hook1
								model.auth = req.auth ? req.auth.userId : 0;
							});
							let newPromise = sub_domains.create({
								subDomainName:element.subDomainName,
								domainId:domain_id,
								status:'active'
							}, {transaction: t});
							promises.push(newPromise);
						}
					});
					return Promise.all(promises); 
				});
			});
		}).then(function (result) {
		  res.send({'status' : true, "message" : 'success'});
		}).catch(function (err) {
			console.log(err);
		  res.send({'status' : false, "message" : 'Fail'});
		});
	}else{
		domain_id>0 ? res.send({'status' : false, 'message':'Un Autherized.'}) : res.send({'status' : false, 'message':'Invalid requiest.'});
	}
});

module.exports = router;