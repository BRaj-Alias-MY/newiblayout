var app = require('express');
var router = app.Router();
var user = require('../models').users;
var config = require('../config/keys');
var crypto = require('crypto');
var jwt = require('jsonwebtoken');
let coupons = require('../models').coupons;
let sequelize = require('../models').sequelize;
const Op = sequelize.Op;

var roles = require('../models').roles;
let user_login_logs = require('../models').user_login_logs;

let mails = require('./email');
const async = require('async');

router.post('/login',(req,res)=>{
    var email = req.body.email;
    var password = crypto.createHash('md5').update(req.body.password).digest('hex');
    user.findOne({ include: [{model:roles} ],where: {email : email,password : password,status:'active'} }).then(users => {
        if(users){
            console.log(users);
            const token = jwt.sign({userId : users.id,organization: users.organizationId,role: users.roleId,roleLevel:users.role.level,email:email},config.secret,{expiresIn : '24h'});
            user_login_logs.create({userId:users.id,token:token,agent:JSON.stringify(req.headers)}).then(rest=>{
                res.send({'status' : true, 'message':'sucess', token : token, user : users});
            }).catch(err=>{
                res.send({'status' : false, 'message':'login.'});
            })
            
        }else{
            res.send({'status' : false, 'message':'fail'});
        }
      }).catch(function (err) {
          console.log(err)
        res.send({'status' : false, 'message':'fail'});
      });

});


router.post('/signup',(req,res)=>{
    var user_data = req.body;
    if(user_data.email!='' && user_data.password!='' && user_data.fname!='' && user_data.lname!=''){
        user.findOne({ where: {email : user_data.email} }).then(users => {
            if(users){
                res.send({'status' : false, 'message':'Email Already Exists.'});
            }else{
				user.afterCreate(function(model, options, done) {//hook1
					model.auth = req.auth ? req.auth.userId : 0;
				});
                user.create({
                    fname:user_data.fname,
                    mname:user_data.mname,
                    lname:user_data.lname,
                    email:user_data.email,
                    password:crypto.createHash('md5').update(user_data.password).digest('hex'),
                    phone:user_data.phone,
                    gender:user_data.gender,
                    status:'active',
                    roleId:5
                }).then((users)=>{
                    res.send({'status':true,'user':users});
                }).catch(function (err) {
                    res.send({'status' : false, 'message':'fail1'});
                });
            }
          }).catch(function (err) {
            res.send({'status' : false, 'message':'fail2'});
          });
    }else{
        res.send({'status' : false, 'message':'Please fill all required fields.'});
    }
});

router.post('/validate-email',(req,res)=>{
    var email = req.body.email;
    user.findOne({ where: {email : email} }).then(users => {
        if(users){
            res.send({'status' : false, 'message':'Email Already Exists.'});
        }else{
            res.send({'status' : true, 'message':'New Email.'});
        }
      }).catch(function (err) {
        res.send({'status' : false, 'message':'fail'});
      });
});

router.post('/forget-password',(req,res)=>{
    let password = require('crypto').randomBytes(7).toString('hex');
    let hash = crypto.createHash('md5').update(password).digest('hex');
    user.afterBulkUpdate(function(options) {//hook1
        options.auth = req.auth ? req.auth.userId : 0;
    });
    user.update({
        password:hash
    },{
        where: {email : req.body.email}
    }).then(result=>{
        //============ send password to mail ====================
        let sendMailPass = [{'content':'Password is '+password,'email':req.body.email}];
        async.parallel([
            function (callback) {
                mails.sendEmail(
                callback,
                'iamchandu.20@gmail.com',
                sendMailPass,
                'IB : Forget Password'
              );
            }
          ], function(err, resss) {

                res.send({'status' : true, data : result});
          });
        //========================================================
        //res.send({'status' : true, data : result});
    });
});

//==================== cron jobs =================================
router.get('/expery-coupans',(req,res)=>{
    var datetime = new Date();
    coupons.update({status:'expired'},{where: { expDate: {[Op.lt]:datetime.setHours(0,0,0,0) },status:'generated' }}).then(result=>{
        res.send({status:true});
    });
});

//================================================================
module.exports = router;