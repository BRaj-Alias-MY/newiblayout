var app = require('express');
var router = app.Router();
var interview_types = require('../models').interview_types;
var interview_type_map = require('../models').interview_type_map;
var interview_type_map_child = require('../models').interview_type_map_child;
var users = require('../models').users;
var user_profile = require('../models').user_profile;
var user_profile_exp = require('../models').user_profile_exp;
var user_profile_edu = require('../models').user_profile_edu;
var user_profile_subdomains = require('../models').user_profile_subdomains;
var sub_domains = require('../models').sub_domains;
var organization_campus = require('../models').organization_campus;
var user_groups_map = require('../models').user_groups_map;
let sequelize = require('../models').sequelize;
const Op = sequelize.Op;


router.get('/admin',(req,res)=>{
    let const_data = {};
    sequelize.query("SELECT roles.role_name,count(*) as cnt FROM `users` left join roles on roles.id = users.roleId where roles.id>2 group by roles.id", { type: sequelize.QueryTypes.SELECT}).then(main_data=>{
      const_data['usersdata'] = {};
      main_data.forEach(element => {
        const_data['usersdata'][element.role_name] = element.cnt;
      });
      sequelize.query("SELECT date_format(createdAt,'%M-%Y') as month,sum(price) as total FROM `payments` WHERE status='sucess' group by date_format(createdAt,'%M-%Y') order by createdAt asc", { type: sequelize.QueryTypes.SELECT}).then(monthlyintData=>{
        const_data['monthlydata'] = monthlyintData;
        sequelize.query("SELECT mode,sum(price) as total FROM `payments` WHERE status='sucess' and date_format(createdAt,'%M-%Y')=date_format(CURDATE(),'%M-%Y') group by mode", { type: sequelize.QueryTypes.SELECT}).then(userdata=>{
          const_data['thismonth'] = userdata;
          res.send({status:true,data:const_data})
        }).catch(err=>{
          res.send({status:false,'message':'fail'})
        })
      }).catch(err=>{
        res.send({status:false,'message':'fail'})
      })
    }).catch(err=>{
      res.send({status:false,'message':'fail'})
    })
})

router.get('/expert',(req,res)=>{
  let const_data = {};
    sequelize.query("SELECT status,count(*) as cnt FROM interview_experts where expertId = "+req.auth.userId+" group by status", { type: sequelize.QueryTypes.SELECT}).then(main_data=>{
      const_data['maindata'] = {};
      main_data.forEach(element => {
        const_data['maindata'][element.status] = element.cnt;
      });
      sequelize.query("SELECT DATE_FORMAT(createdAt, '%M-%Y') as month,count(*) as cnt FROM `interview_experts` where expertId="+req.auth.userId+" group by DATE_FORMAT(createdAt, '%Y-%m')", { type: sequelize.QueryTypes.SELECT}).then(monthlyintData=>{
        const_data['monthlydata'] = monthlyintData;
        sequelize.query("select fname,mname,lname,email,phone,gender from users where id="+req.auth.userId, { type: sequelize.QueryTypes.SELECT}).then(userdata=>{
          const_data['user'] = userdata[0];
          res.send({status:true,data:const_data})
        }).catch(err=>{
          res.send({status:false,'message':'fail'})
        })
      }).catch(err=>{
        res.send({status:false,'message':'fail'})
      })
    }).catch(err=>{
      res.send({status:false,'message':'fail'})
    })
})

router.get('/orgination',(req,res)=>{
  let const_data = {};
  sequelize.query("select *,(total_interviews-active_interviews) as completed from (select (SELECT count(*) as cnt FROM `users` WHERE roleId = 5 and `organizationId`=1) as users,(SELECT count(*) FROM `interview` where date(end_date)>=date(now()) and organizationId="+req.auth.organization+") as active_interviews,(SELECT count(*) FROM `interview` where organizationId=1) as total_interviews) as tab", { type: sequelize.QueryTypes.SELECT}).then(overalldata=>{
    const_data['sumary'] = overalldata[0];
    
      interview_type_map.findAll({include:{model:interview_type_map_child,include:{model:interview_types}}},{where:{organizationId:req.auth.organization,startDate: {[Op.lte]: new Date()},expDate: {[Op.gte]: new Date()}}}).then(palns_data=>{
        const_data['plan'] = palns_data;
        sequelize.query("SELECT date_format(interview_users.createdAt,'%M-%Y')as month,count(*) as cnt FROM `interview_users` left join interview on interview_users.interviewId = interview.id where interview.organizationId="+req.auth.organization+" and interview_users.status in ('Completed','Reviewed','expertreview') group by date_format(interview_users.createdAt,'%Y-%m') order by interview_users.createdAt", { type: sequelize.QueryTypes.SELECT}).then(monthly_int_data=>{
          const_data['monthlydata'] = monthly_int_data;
          res.send({status:true,data:const_data});
        }).catch(err=>{
          res.send({status:false,message:"fail"});
        })
      }).catch(err=>{
        res.send({status:false,message:"fail"});
      })
    
  }).catch(err=>{
    res.send({status:false,message:"fail"});
  })
})

router.get('/user',(req,res)=>{
  users.findAll({include:[{model:user_profile,include:[{model:user_profile_edu},{model:user_profile_exp}]},{model:organization_campus},{model:user_profile_subdomains,include:[{model:sub_domains}]}],where:{id:req.auth.userId}}).then(user=>{
    res.send({status:true,data:user});
  }).catch(err=>{
    console.log(err);
    res.send({status:false,message:'fail'});
  })
})

module.exports = router;

