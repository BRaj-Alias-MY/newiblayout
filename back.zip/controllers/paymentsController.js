let app = require('express');
let router = app.Router();
let coupons = require('../models').coupons;
let interview_type_map = require('../models').interview_type_map;
let interview_type_map_child = require('../models').interview_type_map_child;
let payments = require('../models').payments;
let sequelize = require('../models').sequelize;
const Op = sequelize.Op;

router.post('/orgPaymentMap',async (req,res)=>{
      let userData = req.body;
      console.log(userData);
      if(req.auth.access.addAccess){
            let st = false;
            let msg = 'Un Authorized.';
            let SaveDataObj = {};
            if(req.auth.roleLevel == 1 || req.auth.roleLevel == 2){
                  SaveDataObj['organizationId'] = userData.organization;
                  SaveDataObj['days'] = Number(userData.days);
                  if('cheque'==userData.paymentMode){
                        st = true;
                  }else{
                        msg = 'Payment Mode Should be cheque.';
                  }
            }else if(req.auth.roleLevel == 3 && req.auth.organization){
                  SaveDataObj['organizationId'] = req.auth.organization;
                  SaveDataObj['days'] = 30;
                  if('paypal'==userData.paymentMode){
                        st = true;
                  }else{
                        msg = 'Payment Mode Should be paypal.';
                  }
            }else if(req.auth.roleLevel == 4){
                  SaveDataObj['userId'] = req.auth.userId;
                  SaveDataObj['days'] = 30;
                  if('paypal'==userData.paymentMode){
                        st = true;
                  }else{
                        msg = 'Payment Mode Should be paypal.';
                  }
            }
            if(userData.couponCode){
                  await coupons.findOne({attributes:['id'],where:[{code:userData.couponCode,status:'generated'}]}).then(dataCoupan=>{
                        if(dataCoupan)
                              SaveDataObj['couponCode'] = dataCoupan.id;
                        else{
                              st = false;
                              msg = "coupan code invalid or already used."
                        }
                  }).catch(err=>{
                        st = false;
                        msg = "Fail."
                  })
            }
            SaveDataObj['paymentStatus'] = 'inprogress';
            SaveDataObj['interviews'] = userData.interviews;
            SaveDataObj['paymentMode'] = userData.paymentMode;
            SaveDataObj['startDate'] = userData.startDate;
            SaveDataObj['maxInterviews'] = userData.maxInterviews;
            SaveDataObj['cost'] = userData.cost;
            SaveDataObj['total'] = userData.total;
            SaveDataObj['status'] = 'pending';
            var expdate = new Date(SaveDataObj['startDate']);
            expdate.setDate(expdate.getDate() + SaveDataObj['days']);
            SaveDataObj['expDate'] = expdate;
            let data_tobe_post = {};
            if(st){
                  sequelize.transaction(function (t) {
                        interview_type_map.afterCreate(function(model, options, done) {//hook1
                              model.auth = req.auth ? req.auth.userId : 0;
                        });
                        return interview_type_map.create(SaveDataObj,{transaction: t}).then(resultOfSave=>{
                              data_tobe_post['id'] = resultOfSave.id;
                              interview_type_map_child.afterBulkCreate(function(model,options) {
                                    options.auth = req.auth ? req.auth.userId : 0;
                                });
                              return interview_type_map_child.bulkCreate(userData.interviewtype.map(function(v,i) {
                                    return {interviewTypeId:v.id, interviewTypeMapId:resultOfSave.id};
                              }),{transaction: t}).then(async resultofBulkins=>{
                                    if(SaveDataObj['couponCode']){
                                          coupons.afterBulkUpdate(function(options) {//hook1
                                                options.auth = req.auth ? req.auth.userId : 0;
                                          });
                                          await coupons.update({status:'used'},{
                                                where: {id :  SaveDataObj['couponCode']}
                                          })
                                    }
                                    if(req.auth.roleLevel == 1 || req.auth.roleLevel == 2){
                                          payments.afterCreate(function(model, options, done) {//hook1
                                                model.auth = req.auth ? req.auth.userId : 0;
                                          });
                                          await payments.create({mode:userData.paymentMode,chequeNo:userData.chequeNo,price:userData.total,status:'inprogress',bankName:userData.bankName},{transaction: t}).then(paym=>{
                                                data_tobe_post['paymentId'] = paym.id;
                                          })
                                    }
                                    return true;
                              });
                        })
                  }).then(finalResult=>{
                        //============= save payment details =====================
                        if(req.auth.roleLevel == 1 || req.auth.roleLevel == 2){
                              if(data_tobe_post.paymentId){
                                    interview_type_map.afterBulkUpdate(function(options) {//hook1
                                          options.auth = req.auth ? req.auth.userId : 0;
                                    });
                                    interview_type_map.update({paymentId:data_tobe_post.paymentId},{where:{id:data_tobe_post.id}})
                              }
                              msg = "Success";
                              res.send({status:true,message:msg,data:data_tobe_post});
                        }else{
                              msg = "redirect";
                              res.send({status:true,message:msg,data:data_tobe_post});
                        }
                  }).catch(err=>{
                        console.log(err);
                        res.send({status:false,message:"fail"});
                  });

            }else{
                  res.send({status:st,message:msg})
            }
      }else{
            res.send({status:false,message:"un Authorized."})
      }
});

router.get('/validateorg/:id',(req,res)=>{
      interview_type_map.findOne({attributes:['interviews','total','days','startDate','expDate'],where:{id:req.params.id}}).then(data=>{
            if(data)
                  res.send({status:true,data:data});
            else
                  res.send({status:false,message:'fail'});
      }).catch(err=>{
            res.send({status:false,message:'fail'});
      });
});

router.get('/checkDetails',(req,res)=>{
      if(req.auth.access.gridAccess){
            payments.findAll({where:{status:'inprogress',mode:'cheque'}}).then(data=>{
                  if(data)
                        res.send({status:true,data:data,access:req.auth.access});
                  else
                        res.send({status:false,message:"no data found",access:req.auth.access});
            }).catch(err=>{
                  res.send({status:false,message:"fail.",access:req.auth.access})
            })
      }else{
            res.send({status:false,message:"un Authorized.",access:req.auth.access})
      }
})

router.post('/checkDetails/:id',(req,res)=>{
      if(req.auth.access.editAccess){
            let insData = {status:req.body.status};
            let uporgData = {paymentStatus:req.body.status};
            if(req.body.status=='sucess'){
                  insData['chequeClearedDate'] = req.body.chequeClearedDate;
                  uporgData['status'] = 'active';
            }
            sequelize.transaction(function (t) {
                  payments.afterBulkUpdate(function(options) {//hook1
				options.auth = req.auth ? req.auth.userId : 0;
			});
                  return payments.update(insData,{where:{id:req.params.id}},{transaction: t}).then(result=>{
                        interview_type_map.afterBulkUpdate(function(options) {//hook1
                              options.auth = req.auth ? req.auth.userId : 0;
                        });
                        return interview_type_map.update(uporgData,{where:{paymentId:req.params.id}},{transaction: t});
                  });
            }).then(result=>{
                  res.send({status:true,message:"Status updated."})
            }).catch(err=>{
                  res.send({status:false,message:"fail"})
            });
      }else{
            res.send({status:false,message:"un Authorized."})
      }
});

router.post('/postpayment/:id',(req,res)=>{
      let userData = req.body;
      if(req.params.id){
            let paymentInsData = {mode:userData.paymentMode,chequeNo:0,price:userData.price,pgResponse:JSON.stringify(userData.pgResponse),status:userData.status};
            let update_states = {paymentStatus:userData.status};
            if(userData.status=='sucess'){
                  update_states['status'] = 'active';
            }
            sequelize.transaction(function (t) {
                  payments.afterCreate(function(model, options, done) {//hook1
                        model.auth = req.auth ? req.auth.userId : 0;
                  });
                  return payments.create(paymentInsData,{transaction: t}).then(paym=>{
                        return update_states['paymentId'] = paym.id;
                  })
            }).then(data=>{
                  interview_type_map.afterBulkUpdate(function(options) {//hook1
                        options.auth = req.auth ? req.auth.userId : 0;
                  });
                  interview_type_map.update(update_states,{where:{id:req.params.id}}).then(resDataIns=>{
                        res.send({status:true,message:"success"});
                  }).catch(err=>{
                        console.log(err);
                        res.send({status:false,message:"Fail."})
                  })
            }).catch(err=>{
                  console.log(err);
                  res.send({status:false,message:"Fail."})
            })
      }else{
            res.send({status:false,message:"invalid request."})
      }
});

module.exports = router;

